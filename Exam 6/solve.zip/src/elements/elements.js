export const main = document.querySelector('main');
export const header = document.querySelector('header')