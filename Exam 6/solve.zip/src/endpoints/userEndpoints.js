const baseUrl = 'http://localhost:3030/users/'


export const userEndpoins = {
   login:baseUrl + 'login',
   register:baseUrl + 'register',
   logout:baseUrl + 'logout'
}