export const header = document.querySelector('header');
export const main = document.querySelector('main');